# IHSetPrerpocess

Preprocessing the dataset for IH-SET software

## Installation and use

To install this module use:

```sh
pip install git+git+https://github.com/IHCantabria/IHSetPreprocess.git
```

Run tests to validate:

## Documentation

Documentation is available at https://ihcantabria.github.io/IHSetPreprocess

